package com.example.eric.mymovies.utils;

import com.orhanobut.logger.Logger;

import org.json.JSONArray;
import org.json.JSONObject;

import okhttp3.ResponseBody;

/**
 * Created by eric on 1/4/17.
 */

public class MyJsonResponseUtils {
    public static String extractErrMsg(ResponseBody errorBody) {
        // To parse the error response
        return null;
    }
}
