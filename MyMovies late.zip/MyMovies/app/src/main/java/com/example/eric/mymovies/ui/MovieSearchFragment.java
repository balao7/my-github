package com.example.eric.mymovies.ui;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.eric.mymovies.MyEndlessRVScrollListener;
import com.example.eric.mymovies.R;
import com.example.eric.mymovies.Webservices.MovieService;
import com.example.eric.mymovies.models.Movie;
import com.example.eric.mymovies.models.MoviesResponse;
import com.example.eric.mymovies.utils.MyJsonResponseUtils;
import com.orhanobut.logger.Logger;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by eric on 1/4/17.
 */

public class MovieSearchFragment extends Fragment implements MyEndlessRVScrollListener.OnScrollEndListener {
    private static final String ARG_QUERY = "ARG_QUERY";

    @BindView(R.id.recyclerview)
    RecyclerView recyclerView;
    private String mQuery = "big";
    private MyEndlessRVScrollListener mEndlessScrollListener;
    private int mCurrentPage = 1;
    private int mTotalPageCount;
    private MovieSearchAdapter mAdapter;

    public static MovieSearchFragment newInstance(String query) {

        Bundle args = new Bundle();
        args.putString(ARG_QUERY, query);

        MovieSearchFragment fragment = new MovieSearchFragment();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String tmp = getArguments().getString(ARG_QUERY);
        if (!TextUtils.isEmpty(tmp)) mQuery = tmp;
        mAdapter = new MovieSearchAdapter();
        fetchMovies();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle
            savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie_search, container, false);
        ButterKnife.bind(this, view);
        initViews();
        return view;
    }

    private void initViews() {
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        mEndlessScrollListener = new MyEndlessRVScrollListener(layoutManager, this);
        recyclerView.addOnScrollListener(mEndlessScrollListener);
        recyclerView.setAdapter(mAdapter);
    }

    private void fetchMovies() {
        Logger.i("fetchMovies");
        Call<MoviesResponse> call = MovieService.service.searchMovies(mQuery, mCurrentPage);
        call.enqueue(new Callback<MoviesResponse>() {
            @Override
            public void onResponse(Call<MoviesResponse> call,
                                   Response<MoviesResponse> response) {
                handleResponse(response);
            }

            @Override
            public void onFailure(Call<MoviesResponse> call, Throwable t) {
                Logger.e( "onFailure", t);
                handleFailure();
            }
        });
    }

    private void handleResponse(Response<MoviesResponse> response) {
        Logger.i("handleResponse");
        setLoading(false);
        if (response.isSuccessful()) {
            MoviesResponse tmp = response.body();
            ArrayList<Movie> movies = tmp.getResults();
            mCurrentPage = tmp.getPage();
            mTotalPageCount = tmp.getTotalPages();
            render(movies);
        } else {
            String errorMessage = MyJsonResponseUtils.extractErrMsg(response.errorBody());
            handleFailure(errorMessage);
        }
    }

    private void render(ArrayList<Movie> movies) {
        mAdapter.add(movies);
    }

    private void handleFailure(String errorMessage) {
        Logger.w("handleFailure %s", errorMessage);
    }

    private void handleFailure() {
        Logger.w("handleFailure");
    }

    /**
     * Fetch the next page of movies immediately for smoother scrolling
     */
    @Override
    public void onScrollEnd() {
        Logger.i("onScrollEnd");
        if (mCurrentPage < mTotalPageCount) {
            mCurrentPage++;
            fetchMovies();
        } else {
            recyclerView.removeOnScrollListener(mEndlessScrollListener);
        }
    }

    void setLoading(boolean b) {
        Logger.i("setLoading " + b);
        if (mEndlessScrollListener != null) {
            mEndlessScrollListener.setLoading(b);
        }
    }

    @Override
    public void onDestroyView() {
        recyclerView.removeOnScrollListener(mEndlessScrollListener);
        super.onDestroyView();
    }
}
