package com.example.eric.mymovies;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.example.eric.mymovies.Webservices.MovieService;
import com.example.eric.mymovies.models.Movie;
import com.example.eric.mymovies.models.MoviesResponse;
import com.example.eric.mymovies.ui.MovieSearchFragment;
import com.example.eric.mymovies.utils.MyJsonResponseUtils;
import com.orhanobut.logger.Logger;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    /**
     * value from the search bar
     */
    private String mQuery = "big";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        render();
    }

    private void render() {
        MovieSearchFragment frag = MovieSearchFragment.newInstance(mQuery);
        getSupportFragmentManager().beginTransaction().replace(R.id.frame_movies, frag).commit();
    }
}
